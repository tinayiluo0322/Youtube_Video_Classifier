# Fall2023_IDS703_FinalProject
This is for class NLP YouTube category classification.
